// export const API_URL = process.env.API_URL ?? "https://biyer-ful-server.onrender.com/";
export const API_URL = process.env.API_URL ?? "http://localhost:5000/";