import React from 'react'
const Happiness = () => {
    return (

        <div className="bg-happiness-image  opacity-90 bg-center bg-no-repeat lg:h-[70vh] mt-24">

  
        </div>
    )
}

export default Happiness