import React from 'react'

const AboutPage = () => {
    return (
        <div className=' mt-72 py-16 bg-[#ffffff] text-[#737373] max-w-max'>

            <h1 className='lg:text-4xl text-2xl text-center  '>About Us:</h1>

            <div className='flex flex-col gap-6 mt-8 lg:mx-20 mx-8'>

                <span className='text-xl'>BorBibi.com is a reliable and largest matrimonial platform in bangladesh. It is not an online dating site, it is designed for people who are serious about marriage, and looking for suitable brides or grooms.</span>

                <span className='text-xl'>BorBibi.com will play a great role to connecting worldwide and it playing major role to the bangladeshi community. These matrimonial website are gaining popularity among the worldwide as they are safe and secure (Terms and conditions applied).</span>

                <span className='text-xl'>We can keep the profile confidential and respect the user’s privacy. There are so many features, which makes these websites user friendly. Like these websites send match alerts to prospective grooms and brides through short messaging services.</span>

                <span className='text-xl'>We can also send promotional informing about the latest services they are offering. Matrimony sites are very popular not just among the prospective brides and grooms becoz parents also like it. These online sites have all the detailed information along with their native Districts/city details and also personal phone numbers.</span>

                <span className='text-xl'>Parents can also add profile of their son or daughter on behalf of them. we work for the human benefits by giving all sorts of matrimonial supports in a moment. We have the professional customer support manager who has the experience in providing the customer the best services, so to get the services by us please connect to us.</span>

                <span className='text-xl'>We have been working since 2011 with the great customer satisfaction.BorBibi.com is the professional matrimonial service provider in bangladesh. Our goal is to help you find your life partner, change the way people find their life partner.</span>


            </div>

        </div>
    )
}

export default AboutPage