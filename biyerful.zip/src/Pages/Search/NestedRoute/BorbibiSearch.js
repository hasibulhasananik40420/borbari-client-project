import React from 'react'

const BorbibiSearch = () => {
  return (
    <div>
      <h1 className='text-xl text-[#737373]'>You are not allowd To Borbibi search! Please upgrade your membership level.</h1>
    </div>
  )
}

export default BorbibiSearch